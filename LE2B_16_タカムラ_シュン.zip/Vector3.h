#pragma once
struct Vector3 {
	float x, y, z;
};