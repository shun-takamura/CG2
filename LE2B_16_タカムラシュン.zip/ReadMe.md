三角形を表示しImGuiで色を変更可能

実装済みの加点要素
三角形を動かす
Textureを貼る
DepthBufferの利用
Textureの動的切り替え